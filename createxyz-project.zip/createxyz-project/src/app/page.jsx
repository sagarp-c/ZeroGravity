"use client";
import React from "react";

function MainComponent() {
  const [currentPage, setCurrentPage] = React.useState("home");
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);

  const pages = {
    home: <HomePage setCurrentPage={setCurrentPage} />,
    onboarding: (
      <Onboarding
        setIsLoggedIn={setIsLoggedIn}
        setCurrentPage={setCurrentPage}
      />
    ),
    subscription: <Subscription />,
    orders: <Orders />,
    profile: <Profile />,
  };

  return (
    <div className="font-roboto bg-green-50 min-h-screen text-green-800">
      {!isLoggedIn ? (
        <Onboarding
          setIsLoggedIn={setIsLoggedIn}
          setCurrentPage={setCurrentPage}
        />
      ) : (
        <div className="flex flex-col h-screen">
          <header className="bg-green-600 text-white p-4">
            <h1 className="text-2xl font-bold">GreenTray</h1>
          </header>
          <main className="flex-grow overflow-y-auto p-4">
            {pages[currentPage]}
          </main>
          <nav className="bg-white border-t border-green-200">
            <ul className="flex justify-around p-2">
              <NavItem
                icon="fa-home"
                label="Home"
                onClick={() => setCurrentPage("home")}
              />
              <NavItem
                icon="fa-list"
                label="Subscription"
                onClick={() => setCurrentPage("subscription")}
              />
              <NavItem
                icon="fa-shopping-basket"
                label="Orders"
                onClick={() => setCurrentPage("orders")}
              />
              <NavItem
                icon="fa-user"
                label="Profile"
                onClick={() => setCurrentPage("profile")}
              />
            </ul>
          </nav>
        </div>
      )}
    </div>
  );
}

function NavItem({ icon, label, onClick }) {
  return (
    <li className="text-center" onClick={onClick}>
      <i className={`fas ${icon} text-2xl text-green-600`}></i>
      <p className="text-xs mt-1">{label}</p>
    </li>
  );
}

function HomePage({ setCurrentPage }) {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Welcome to GreenTray</h2>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Today's Recommendations</h3>
        <div className="flex space-x-4 overflow-x-auto pb-2">
          <ProductCard name="Organic Apples" price="$2.99" image="/apple.jpg" />
          <ProductCard
            name="Fresh Spinach"
            price="$1.99"
            image="/spinach.jpg"
          />
          <ProductCard
            name="Whole Grain Bread"
            price="$3.49"
            image="/bread.jpg"
          />
        </div>
      </section>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Upcoming Delivery</h3>
        <p>Your next delivery is scheduled for tomorrow at 10:00 AM</p>
        <button
          className="mt-2 bg-green-600 text-white px-4 py-2 rounded"
          onClick={() => setCurrentPage("orders")}
        >
          View Order
        </button>
      </section>
    </div>
  );
}

function ProductCard({ name, price, image }) {
  return (
    <div className="flex-shrink-0 w-32">
      <img
        src={image}
        alt={name}
        className="w-full h-32 object-cover rounded"
      />
      <p className="mt-1 font-semibold">{name}</p>
      <p>{price}</p>
    </div>
  );
}

function Onboarding({ setIsLoggedIn, setCurrentPage }) {
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-green-100 p-4">
      <h1 className="text-3xl font-bold text-green-800 mb-8">
        Welcome to GreenTray
      </h1>
      <p className="text-center mb-8">
        Customized grocery subscriptions with daily deliveries and eco-friendly
        packaging.
      </p>
      <button
        className="bg-green-600 text-white px-6 py-3 rounded-full text-lg mb-4"
        onClick={() => {
          setIsLoggedIn(true);
          setCurrentPage("home");
        }}
      >
        Get Started
      </button>
      <p className="text-sm">
        Already have an account?{" "}
        <span className="text-green-600 underline">Log in</span>
      </p>
    </div>
  );
}

function Subscription() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Your Subscription</h2>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Current Plan</h3>
        <p>Weekly Delivery</p>
        <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded">
          Modify Plan
        </button>
      </section>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Next Delivery</h3>
        <p>Monday, 10:00 AM</p>
        <button className="mt-2 border border-green-600 text-green-600 px-4 py-2 rounded">
          Change Time
        </button>
      </section>
    </div>
  );
}

function Orders() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Your Orders</h2>
      <OrderItem date="May 15, 2024" status="Delivered" items={3} />
      <OrderItem date="May 22, 2024" status="Processing" items={5} />
    </div>
  );
}

function OrderItem({ date, status, items }) {
  return (
    <div className="bg-white rounded-lg p-4 shadow">
      <div className="flex justify-between items-center mb-2">
        <p className="font-semibold">{date}</p>
        <span
          className={`px-2 py-1 rounded ${
            status === "Delivered"
              ? "bg-green-200 text-green-800"
              : "bg-yellow-200 text-yellow-800"
          }`}
        >
          {status}
        </span>
      </div>
      <p>{items} items</p>
      <button className="mt-2 text-green-600 underline">View Details</button>
    </div>
  );
}

function Profile() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Your Profile</h2>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Personal Information</h3>
        <p>Name: John Doe</p>
        <p>Email: john@example.com</p>
        <button className="mt-2 bg-green-600 text-white px-4 py-2 rounded">
          Edit Profile
        </button>
      </section>
      <section className="bg-white rounded-lg p-4 shadow">
        <h3 className="font-semibold mb-2">Eco Impact</h3>
        <p>Plastic saved: 2.5 kg</p>
        <p>Food waste reduced: 5 kg</p>
      </section>
    </div>
  );
}

export default MainComponent;